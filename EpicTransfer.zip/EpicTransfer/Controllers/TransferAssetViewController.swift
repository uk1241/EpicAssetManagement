//
//  TransferAssetViewController.swift
//  EpicTransfer
//
//  Created by R.Unnikrishnan on 28/03/23.
//

import UIKit

class TransferAssetViewController: UIViewController {

    @IBOutlet weak var assetAddButton: UIButton!
    @IBOutlet weak var transferAssetButton: UIButton!
    
    @IBOutlet weak var addAssetButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        navigationItem.title = "Transfer Assets"
    
    }
    @IBAction func transferAssetButtonAction(_ sender: Any)
    {
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "TransferSuccessViewController") as! TransferSuccessViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }

}

extension TransferAssetViewController : UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TransferAssetTableViewCell", for: indexPath) as! TransferAssetTableViewCell
        return cell
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "TransferAssetTableViewCell", for: indexPath) as! TransferAssetTableViewCell
//        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//        let vc = storyBoard.instantiateViewController(withIdentifier: "AddAssetViewController") as! AddAssetViewController
//        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
