//
//  TransferAssetViewController.swift
//  EpicTransfer
//
//  Created by R.Unnikrishnan on 28/03/23.
//

import UIKit


let laptopModels = ["MacBook Air", "MacBook Pro", "Dell XPS 13", "HP Spectre x360","MacBook Air", "MacBook Pro", "Dell XPS 13", "HP Spectre x360","MacBook Air", "MacBook Pro", "Dell XPS 13", "HP Spectre x360"]

class MyAssetViewController: UIViewController, UINavigationControllerDelegate {
    var select = false
    
    @IBOutlet weak var tableView: UITableView!
    
    
    
    var isselecte = [Int:Bool]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        selected()
        configureItems()
        navigationController?.isNavigationBarHidden = false
        navigationController?.delegate = self
       
    }
    
//    private func selected()
//    {
//        for i in 0...laptopModels.count
//        {
//            isselecte[i] = false
//        }
//    }
    private func selected()
    {
        for i in 0..<laptopModels.count
        {
            isselecte[i] = false
        }
    }

    
    
    
    private func configureItems()
    {
        
        let button = UIBarButtonItem(title: "Select", style: .plain, target: self, action: #selector(navbarButtonAction))
         // Set the title text attributes to white color
        button.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.white], for: .normal)
        // Set the UIBarButtonItem as the right bar button item
        navigationItem.rightBarButtonItem = button
        
    }
    
    
    @objc func navbarButtonAction(_ sender: UIBarButtonItem)
    {
        if select == false
        {
                sender.title = "Done"
                select = true
                tableView.reloadData()
        }
        else
        {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "AssetViewController") as! AssetViewController
            vc.isselected = isselecte
            self.navigationController?.pushViewController(vc, animated: true)
        }
        if isselecte.count == 0
        {
             select = false
            sender.title = "Select"
            tableView.reloadData()
        }
      
        
        
    }
    
}


extension MyAssetViewController : UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return laptopModels.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyAssetTableViewCell", for: indexPath) as! MyAssetTableViewCell
        if select == false{
            cell.imageOutlet.isHidden = true
        }
        else
        {
            cell.imageOutlet.isHidden = false
        }
        
        if isselecte[indexPath.row] == true {
            cell.imageOutlet.image = UIImage(named: "check")
            cell.labelOutlet.text = laptopModels[indexPath.row]
        } else {
            cell.imageOutlet.image = UIImage(named: "untick")
            cell.labelOutlet.text = laptopModels[indexPath.row]
        }
        
        cell.selectionStyle = .none
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath) as! MyAssetTableViewCell
            cell.imageOutlet.image = UIImage(named: "check")
        
        
        if select == false
            
        {
          
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "ProductDetailViewController") as! ProductDetailViewController
            self.navigationController?.pushViewController(vc, animated: true)
            cell.imageOutlet.image = UIImage(named: "untick")
        }
        else
        {
            select = true
            isselecte[indexPath.row] = true
//            cell.imageOutlet.image = UIImage(named: "untick")
        }
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath) as! MyAssetTableViewCell
        cell.imageOutlet.image = UIImage(named: "untick")
        if select == false
            
        {
          
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "ProductDetailViewController") as! ProductDetailViewController
            self.navigationController?.pushViewController(vc, animated: true)
            cell.imageOutlet.image = UIImage(named: "untick")
        }
        else
        {
            select = true
            isselecte[indexPath.row] = false
            cell.imageOutlet.image = UIImage(named: "untick")
        }
        
    }
    
    
    @objc func buttonAction()
    {
        print("you have tapped")
    }
    
    
}
