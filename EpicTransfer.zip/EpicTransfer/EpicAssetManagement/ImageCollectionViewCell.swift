//
//  ImageCollectionViewCell.swift
//  EpicAssetManagement
//
//  Created by USER on 02/03/23.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageViewOutlet: UIImageView!
    
}
